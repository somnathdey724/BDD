package com.cg.project.stepdefinations;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import com.cg.project.pagebeans.LoginPage;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
public class GithubLoginStepsDefination  {
	WebDriver driver;
	LoginPage loginPage;
	@Given("^User is on github home page$")
	public void user_is_on_github_home_page() throws Throwable {
		System.setProperty("webdriver.chrome.driver","D:\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.get("https://github.com/login");
	}

	@When("^User fills the correct email and incorrect password$")
	public void user_fills_the_correct_email_and_incorrect_password() throws Throwable {
	   /* By usernameField= By.name("login");
	    WebElement username=driver.findElement(usernameField);
	    username.sendKeys("somnathdey724@gmail.com");
	    By passwordField=By.name("password");
	    WebElement password=driver.findElement(passwordField);
	    password.sendKeys("password");
	    By submitField= By.name("commit");
	    WebElement submitButton=driver.findElement(submitField);
	    submitButton.submit();*/
		loginPage.setUsername("somnathdey724");
		loginPage.setPassword("Sushant@123");
		loginPage.clickSignIn();
	}

	@Then("^Display GitHub 'login Page' with error message$")
	public void display_GitHub_login_Page_with_error_message() throws Throwable {
	    String actualTitle=driver.getTitle();
	    System.out.println(actualTitle);
	    String expectedTitle="Sign in to GitHub � GitHub";
	    Assert.assertEquals(actualTitle, expectedTitle);
	}

	@When("^User fills the incorrect email and correct password$")
	public void user_fills_the_incorrect_email_and_correct_password() throws Throwable {
		/*	By usernameField= By.name("login");
		    WebElement username=driver.findElement(usernameField);
		    username.sendKeys("ABC@gmail.com");
		    By passwordField=By.name("password");
		    WebElement password=driver.findElement(passwordField);
		    password.sendKeys("Somnath@1");
		    By submitField= By.name("commit");
		    WebElement submitButton=driver.findElement(submitField);
		    submitButton.submit();*/
		loginPage.setUsername("sushantdey");
		loginPage.setPassword("Somnath@1");
		loginPage.clickSignIn();
	}
	@Then("^Display GitHub 'login Page' with error messages$")
	public void display_GitHub_login_Page_with_error_messages() throws Throwable {
		  String actualTitle=driver.getTitle();
		    System.out.println(actualTitle);
		    String expectedTitle="Sign in to GitHub � GitHub";
		    Assert.assertEquals(actualTitle, expectedTitle);
	}

	@When("^User fills the correct email and correct password$")
	public void user_fills_the_correct_email_and_correct_password() throws Throwable {
		/*By usernameField= By.name("login");
	    WebElement username=driver.findElement(usernameField);
	    username.sendKeys("somnathdey724@gmail.com");
	    By passwordField=By.name("password");
	    WebElement password=driver.findElement(passwordField);
	    password.sendKeys("Somnath@1");
	    By submitField= By.name("commit");
	    WebElement submitButton=driver.findElement(submitField);
	    submitButton.submit();*/
		loginPage.setUsername("somnathdey724");
		loginPage.setPassword("Somnath@1");
		loginPage.clickSignIn();
	}

	@Then("^Display GitHub User Page$")
	public void display_GitHub_User_Page() throws Throwable {
		 String actualTitle=driver.getTitle();
		    String expectedTitle="GitHub";
		    Assert.assertEquals(actualTitle, expectedTitle);
		    driver.close();
	}
}
