package com.cg.project.stepdefinations;
import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
public class GmailLoginStepsDefination {
	@When("^User search for 'Gmail'$")
	public void user_search_for_Gmail() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^All links should display with 'Gmail'$")
	public void all_links_should_display_with_Gmail() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Given("^User is on resultPage$")
	public void user_is_on_resultPage() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^User clicks 'www\\.google\\.com/gmail/'$")
	public void user_clicks_www_google_com_gmail() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^Display gmail 'login page'$")
	public void display_gmail_login_page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Given("^User is on Login Page$")
	public void user_is_on_Login_Page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^User enter correct the email and password$")
	public void user_enter_correct_the_email_and_password() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^User gmail account displayed$")
	public void user_gmail_account_displayed() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^User fills the incorrect email or password$")
	public void user_fills_the_incorrect_email_or_password() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^Display gmail 'Login Page' with correction message$")
	public void display_gmail_Login_Page_with_correction_message() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}


}
