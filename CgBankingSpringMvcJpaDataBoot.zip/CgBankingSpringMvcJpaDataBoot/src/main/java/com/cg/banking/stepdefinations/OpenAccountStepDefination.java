package com.cg.banking.stepdefinations;
import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;
import com.cg.banking.pagebeans.OpenAccountPage;
import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
public class OpenAccountStepDefination {
	WebDriver driver;
	OpenAccountPage openAccountpage;
	@Given("^User is on Open Account Page$")
	public void user_is_on_Open_Account_Page() throws Throwable {
		System.setProperty("webdriver.chrome.driver","D:\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.get("http://localhost:2112/openAccount");
		openAccountpage=PageFactory.initElements(driver, OpenAccountPage.class);
	}

	@When("^User enters correct pinNumber accounttype accountBalance$")
	public void user_enters_correct_pinNumber_accounttype_accountBalance() throws Throwable {
	   openAccountpage.setPinNumber("0123");
	   openAccountpage.setAccountType("Saving");
	   openAccountpage.setAccountBalance("2000");
	   openAccountpage.onClick();
	}

	@Then("^User bank account created with accountNumber$")
	public void user_bank_account_created_with_accountNumber() throws Throwable {
		String actualTitle = driver.getTitle();
		String expectedTitle="Registration Success";
		Assert.assertEquals(actualTitle, expectedTitle);
		driver.close();
	}

	@When("^User enters incorrect format for pinNumber or accountType or accountBalance$")
	public void user_enters_incorrect_format_for_pinNumber_or_accountType_or_accountBalance() throws Throwable {
		  openAccountpage.setPinNumber("abcdef");
		   openAccountpage.setAccountType("Saving");
		   openAccountpage.setAccountBalance("2000");
		   openAccountpage.onClick();
	}

	@Then("^User is on 'Open Account' Page with error message$")
	public void user_is_on_Open_Account_Page_with_error_message() throws Throwable {
		String actualTitle = driver.getTitle();
		String expectedTitle="Open Account";
		Assert.assertEquals(actualTitle, expectedTitle);
		driver.close();
	}
}
