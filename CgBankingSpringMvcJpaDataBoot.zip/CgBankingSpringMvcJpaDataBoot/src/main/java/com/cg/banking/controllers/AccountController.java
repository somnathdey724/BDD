package com.cg.banking.controllers;
import java.util.ArrayList;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import com.cg.banking.beans.Account;
import com.cg.banking.beans.Transaction;
import com.cg.banking.exceptions.AccountBlockedException;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.BankingServicesDownException;
import com.cg.banking.exceptions.InsufficientAmountException;
import com.cg.banking.exceptions.InvalidPinNumberException;
import com.cg.banking.exceptions.TransactionRollbackException;
import com.cg.banking.services.BankingServices;
@Controller
public class AccountController {
	@Autowired
	BankingServices bankingServices;
	@RequestMapping("/openingAccount")
	public ModelAndView registerAccount(@Valid@ModelAttribute Account account,BindingResult bindingResult) {
		if(bindingResult.hasErrors())
			return new ModelAndView("openAccountPage");
		account= bankingServices.openAccount(account);
		return new ModelAndView("registrationSuccessPage", "account", account);
	}
	@RequestMapping("/depositingPage")
	public ModelAndView deposit(@RequestParam("accountNo")long accountNo,@RequestParam("accountBalance")float accountBalance) throws AccountNotFoundException, BankingServicesDownException, InsufficientAmountException {
		try{
			accountBalance= bankingServices.depositAmount(accountNo, accountBalance);
			return new ModelAndView("DepositSuccessPage", "accountBalance", accountBalance);
		}catch (AccountNotFoundException e) {
			return new ModelAndView("accountNoDepositPage","errorMessage","Account Number not found,pls try again!!");
		}
	}
	@RequestMapping("/withdrawingPage")
	public ModelAndView withdraw(@RequestParam("accountNo")long accountNo,@RequestParam("accountBalance")float accountBalance,@RequestParam("pinNumber")int pinNumber) throws AccountNotFoundException, BankingServicesDownException, InsufficientAmountException, InvalidPinNumberException {

		try {
			accountBalance= bankingServices.withdrawAmount(accountNo, accountBalance, pinNumber);
			return new ModelAndView("WithdrawSuccessPage", "accountBalance", accountBalance);
		}catch (AccountNotFoundException e) {
			return new ModelAndView("accountNoWithdrawPage","errorMessage","Account Number not found,pls try again!!");
		}catch (InsufficientAmountException e) {
			return new ModelAndView("accountNoWithdrawPage","errorMessage","Insufficient Amount,pls try again!!");

		}catch (InvalidPinNumberException e) {
			return new ModelAndView("accountNoWithdrawPage","errorMessage","Invalid Pin Number,pls try again!!");

		}
	}
	@RequestMapping("/fundTransferring")
	public ModelAndView fundTransfer(@RequestParam("accountNoTo")long accountNoTo,@RequestParam("accountNoFrom")long accountNoFrom,@RequestParam("transferAmount")float transferAmount,@RequestParam("pinNumber")int pinNumber) throws AccountNotFoundException, BankingServicesDownException, InsufficientAmountException, InvalidPinNumberException, AccountBlockedException {
		try {
			bankingServices.fundTransfer(accountNoTo, accountNoFrom, transferAmount, pinNumber);
			return new ModelAndView("TransferSuccessPage", "transferAmount", transferAmount);
		}catch (AccountNotFoundException e) {
			return new ModelAndView("fundTransferPage","errorMessage","Account number Not found");
		}catch (InvalidPinNumberException e) {
			return new ModelAndView("fundTransferPage","errorMessage","Invalid Pin Number,pls try again!!");
		}catch (InsufficientAmountException e) {
			return new ModelAndView("fundTransferPage","errorMessage","Insufficient Balance");
		}	
	}
	@RequestMapping("/accountDetail")
	public ModelAndView accountDetails(@ModelAttribute Account account,@RequestParam("accountNo")long accountNo) throws BankingServicesDownException {
		try {
			account= bankingServices.getAccountDetails(accountNo);
			return new ModelAndView("accountDetailsPage", "account", account);
		}catch (AccountNotFoundException e) {
			return new ModelAndView("accountNoAccountDetails","errorMessage","Account Number not found,pls try again!!");
		}
	}

	@RequestMapping("/allAccountDetails")
	public ModelAndView allAccountDetails(@ModelAttribute Account account) throws AccountNotFoundException, BankingServicesDownException {
		ArrayList<Account> accounts= (ArrayList<Account>) bankingServices.getAllAccountDetails();
		return new ModelAndView("allAccountDetailsPage", "accounts", accounts);
	}

	@RequestMapping("/transactionDetails")
	public ModelAndView AccountTransaction(@Valid@ModelAttribute Transaction transaction,@RequestParam("accountNo")long accountNo,BindingResult bindingResult) throws AccountNotFoundException, BankingServicesDownException, TransactionRollbackException {
		if(bindingResult.hasErrors())
			return new ModelAndView("fundTransferPage");
		try {
			ArrayList<Transaction> transactions= (ArrayList<Transaction>) bankingServices.getAccountAllTransaction(accountNo);
			return new ModelAndView("accountTransactionsPage", "transactions", transactions);
		}catch(AccountNotFoundException e) {
			return new ModelAndView("accountNoAccountTransaction","errorMessage","Account Number not found,pls try again!!");
		}
	}
}