package com.cg.banking.stepdefinations;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import com.cg.banking.pagebeans.DepositPage;
import com.cg.banking.pagebeans.OpenAccountPage;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class DepositStepDefination {
	WebDriver driver;
	DepositPage depositPage;
	@Given("^User is on Banking Deposit Page$")
	public void user_is_on_Banking_Deposit_Page() throws Throwable {
		System.setProperty("webdriver.chrome.driver","D:\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.get("http://localhost:2112/depositPage");
		depositPage=PageFactory.initElements(driver, DepositPage.class);
	}

	@When("^User enters correct values for accountNumber and accountBalance$")
	public void user_enters_correct_values_for_accountNumber_and_accountBalance() throws Throwable {
	   depositPage.setAccountNo("1");
	   depositPage.setAccountBalance("5000");
	   depositPage.onClick();
	}

	@Then("^User gets his current bank balance in 'Deposit Successful' Page$")
	public void user_gets_his_current_bank_balance_in_Deposit_Successful_Page() throws Throwable {
		String actualTitle = driver.getTitle();
		String expectedTitle="DepositSuccessful";
		Assert.assertEquals(actualTitle, expectedTitle);
		driver.close();
	}

	@When("^User enters incorrect values for accountNumber$")
	public void user_enters_incorrect_values_for_accountNumber() throws Throwable {
		  depositPage.setAccountNo("11111");
		   depositPage.setAccountBalance("5000");
		   depositPage.onClick();
	}

	@Then("^User is on 'Deposit Page' with error message$")
	public void user_is_on_Deposit_Page_with_error_message() throws Throwable {
		String actualTitle = driver.getTitle();
		String expectedTitle="Deposit";
		Assert.assertEquals(actualTitle, expectedTitle);
		driver.close();
	}
}
