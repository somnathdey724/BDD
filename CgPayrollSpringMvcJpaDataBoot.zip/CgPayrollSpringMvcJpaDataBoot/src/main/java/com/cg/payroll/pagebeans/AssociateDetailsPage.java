package com.cg.payroll.pagebeans;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class AssociateDetailsPage {
	@FindBy(how=How.NAME,name="associateId")
	private WebElement associateId;
	@FindBy(name="submit")
	private WebElement submit;
	
	  
	
	public AssociateDetailsPage() {}
	
	public String getAssociateId() {
		return associateId.getAttribute("value");
	}
	public void setAssociateId(String associateId) {
		this.associateId.sendKeys(associateId);;
	}
	public void clickSignIn() {
		submit.click();
	}
}
