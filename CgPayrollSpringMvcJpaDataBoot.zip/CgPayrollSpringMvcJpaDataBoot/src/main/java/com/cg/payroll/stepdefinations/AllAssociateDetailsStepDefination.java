package com.cg.payroll.stepdefinations;
import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;
import com.cg.payroll.pagebeans.AllAssociateDetailsPage;
import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
public class AllAssociateDetailsStepDefination {
	WebDriver driver;
	AllAssociateDetailsPage allAssociateDetailsPage;
	@Given("^User is on Capgemini Home Page$")
	public void user_is_on_Capgemini_Home_Page() throws Throwable {
		System.setProperty("webdriver.chrome.driver","D:\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.get("http://localhost:1278/home");
		allAssociateDetailsPage=PageFactory.initElements(driver, AllAssociateDetailsPage.class);
	}

	@When("^User clicks on 'All Associate details' button$")
	public void user_clicks_on_All_Associate_details_button() throws Throwable {
	    allAssociateDetailsPage.clickSignIn();
	}

	@Then("^User is on 'All Associate details Page'$")
	public void user_is_on_All_Associate_details_Page() throws Throwable {
			String actualTitle=driver.getTitle();
		    System.out.println(actualTitle);
		    String expectedTitle="All Associate Details";
		    Assert.assertEquals(actualTitle, expectedTitle);
	}
}
