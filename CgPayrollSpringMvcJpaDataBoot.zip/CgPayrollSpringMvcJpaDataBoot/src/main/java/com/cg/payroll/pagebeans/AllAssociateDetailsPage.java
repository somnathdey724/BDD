package com.cg.payroll.pagebeans;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
public class AllAssociateDetailsPage {
	@FindBy(name="allAssociateDetails")
	private WebElement submit;

	public AllAssociateDetailsPage() {
		super();
	}

	public void clickSignIn() {
		submit.click();
	}
}
